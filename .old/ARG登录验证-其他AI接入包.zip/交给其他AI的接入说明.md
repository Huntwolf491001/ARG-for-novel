# ARG 登录验证服务：给网站开发 AI 的接入说明

本文件适用于将网站接入现有验证服务，目标托管环境为 Cloudflare Pages。与本文件同目录的 `_worker.js` 是服务端保护适配器；请一并提供给开发 AI。本文没有包含任何账号密码或密钥。

## 给开发 AI 的任务

请在写代码前向网站所有者确认：是否接入本验证服务、网站正式 HTTPS 地址、站点 ID、受保护目录、成功后的目标页面、登录页面位置，以及是否需要二级密码和找回流程。账号和密码由所有者指定并安全登记，不要编造。确认后检查项目并实现完整接入，验证实际部署；只有取得相应授权和权限才能修改 Cloudflare 资源。不要声称未做过的测试或部署已完成。

服务地址和管理面板：`https://arg-auth-683dc0f14848.yangyi42905341.workers.dev`。该 `workers.dev` 地址在部分中国大陆网络上可能无法连接；接入前分别测试浏览器到服务、Pages 到服务的连通性。验证服务不可用时，受保护页面会返回 503。不要假定代理、自定义域名或 Pages 可用就能解决该问题。

## 站点登记及秘密

1. 管理员登录控制面板，创建站点，填写站点名称、唯一 ID、目标站点 HTTPS origin、保护目录和成功后的目标路径。例如：ID `example-site`、origin `https://example-site.pages.dev`、目录 `/archive/`、目标 `/archive/index.html`。这些只是示例，不能沿用到其他站点。
2. 在面板为该站点创建玩家账号密码。需要两步验证时，另外登记二级密码和找回问题的答案。账号、密码和答案由用户本人通过可信界面输入；密码只保存不可逆摘要，不能查看，只能重设。
3. 站点所有者从后台取得该站点的 `SITE_KEY`，通过 Cloudflare Pages 的 Secret 安全配置。`SITE_KEY`、玩家密码、管理员密码和会话令牌不得写进源码、网页、仓库、构建产物、聊天或日志。不要要求用户在聊天中提供秘密，也不要将秘密放到命令行参数。可使用管理后台完成登记；管理员可在可信终端使用本项目 `arg-auth/scripts/register-account.js` 交互式登记。
4. 在控制面板更改站点 ID、origin 或保护目录后，必须同步更新 Pages 的配置并重新部署。签名密钥不是浏览器表单所需的参数。

## Pages 保护适配器

先检查已有 `_worker.js`、`functions/`、构建过程、重写规则与静态资源路由。本适配器使用 Pages 高级模式；若已有 Worker 或 Functions，应合并鉴权并测试既有功能，不得直接覆盖。确认 `_worker.js` 进入实际构建输出目录根部。所有需要保密的 HTML、图片、PDF、JSON 等必须位于保护目录下；公开仓库、旧压缩包、其他部署、预览地址、缓存或替代路径里的副本不受本适配器保护。

在 Pages 项目生产环境配置并重新部署：

| 变量 | 含义 | 类型 |
| --- | --- | --- |
| `AUTH_ORIGIN` | 验证服务地址，见上文 | 普通变量 |
| `SITE_ORIGIN` | 已登记的目标站点 origin，不含路径或尾部斜杠 | 普通变量 |
| `SITE_ID` | 已登记的站点 ID | 普通变量 |
| `PROTECTED_PREFIX` | 已登记的目录，如 `/archive/` | 普通变量 |
| `LOGIN_PATH` | 可选，同站公开登录路径，如 `/login.html` | 普通变量 |
| `SITE_KEY` | 后台生成的该站点签名密钥 | Secret |

站点 ID 只接受小写字母、数字和连字符，最长 40 位；目录需以 `/` 开头和结尾，目录段使用英文字母、数字、下划线或连字符。成功目标必须是保护目录内的路径。生产域名、预览域名和自定义域名各自是不同 origin；本适配器只接受已配置的一个 origin。不要为了让预览通过而取消校验或暴露受保护资源。

## 玩家登录 API

对于普通单步账号，从已登记的目标站点页面发送：

```text
POST https://arg-auth-683dc0f14848.yangyi42905341.workers.dev/api/player/login?site=站点ID
Content-Type: application/json

{"site":"站点ID","username":"用户输入的账号","password":"用户输入的密码"}
```

不要把示例中的字段值替换为真实账号密码后保存到文件。浏览器请求需来自已登记的 origin；跨域请求的查询参数 `site` 与 JSON 中的站点 ID 必须一致。通过时返回 `{ "redirect": "https://目标站点/_arg/callback?ticket=..." }`；页面使用 `location.assign(data.redirect)` 完成跳转。适配器兑换一次性票据并设置 `HttpOnly`、`Secure` 的站点 Cookie。失败时检查 HTTP 状态及 `error`，向用户显示合理错误，不输出凭据、proof 或 ticket。面板的集成代码可作为普通单步登录表单的起点。

若该账号配置了二级验证，第一步成功返回 `{ "stage":"appeal", "proof":"..." }`，而非 `redirect`。接着向 `/api/player/appeal?site=站点ID` POST JSON：`{ "site":"站点ID", "proof":"上一步返回值", "password":"用户输入的二级密码" }`，成功才返回 `redirect`。不得把 proof 持久化或写进日志。通用单步示例不能直接处理二级验证，必须实现第二步界面。

可选找回流程：`POST /api/player/recover/start?site=站点ID`，JSON 为 `{site, username}`；成功得到 `proof`。然后 `POST /api/player/recover/answer?site=站点ID`，JSON 为 `{site, proof, answer}`，成功得到二级验证阶段的 `proof`，再调用上面的 `appeal`。该流程是否启用和问题文字由站点作者决定；不要将找回答案写进前端。所有这些请求都应从已登记的 origin 发起，结果取决于账户是否已登记对应的二级验证。

## 退出与会话

在受保护页面添加同源 POST 表单：

```html
<form action="/_arg/logout" method="post"><button type="submit">退出</button></form>
```

更新后的适配器会撤销当前会话并清除 Cookie；其他独立会话不受影响。票据有效期 60 秒且只能兑换一次，会话最长 8 小时；每次请求受保护资源会联系验证服务检查会话。修改密码不会自动撤销所有已发出的站点会话。不要把票据放在页面链接、分析日志或第三方脚本中。

## 验收与报告

在隔离浏览器或测试账号下检查：公开页面；直接访问保护目录及其中图片/PDF；错误账号密码；成功登录及二级流程（如启用）；同一票据重复使用；退出后重用之前的 Cookie；验证服务不可用时的处理；其他域名、预览、旧部署、仓库和公开副本。检查时不要输出密码、Cookie、票据或密钥。

向用户报告哪些已部署、哪些实际测过、测试环境与结果、哪些需要所有者在 Cloudflare 中配置，以及尚未验证的部分。不能将前端隐藏或跳转描述为访问保护。
