@echo off
start "" "https://zhengzhou-forum.pages.dev/"
