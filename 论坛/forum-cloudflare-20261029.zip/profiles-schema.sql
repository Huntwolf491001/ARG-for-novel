CREATE TABLE IF NOT EXISTS forum_profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_key TEXT NOT NULL UNIQUE,
  uid TEXT UNIQUE,
  existing_uid TEXT,
  display_name TEXT NOT NULL,
  avatar TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  CHECK (existing_uid IS NULL OR length(existing_uid)=8)
);
CREATE UNIQUE INDEX IF NOT EXISTS forum_profiles_existing_uid ON forum_profiles(existing_uid) WHERE existing_uid IS NOT NULL;
