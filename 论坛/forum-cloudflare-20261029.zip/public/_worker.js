// Based on the supplied ARG Pages adapter; all forum resources require a session.
const enc = new TextEncoder();
const PUBLIC = new Set(['/entry.html', '/entry.css', '/entry.js']);
const unb64 = text => Uint8Array.from(atob(text.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4-text.length%4)%4)), c=>c.charCodeAt(0));
const now = () => Math.floor(Date.now()/1000);
const hex = bytes=>Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
const sha = text=>crypto.subtle.digest('SHA-256',enc.encode(text)).then(hex);
async function accountKey(env,username){const key=await crypto.subtle.importKey('raw',enc.encode(env.SITE_KEY),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',key,enc.encode('forum-account:'+username)));}
const b64 = bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
async function sign(payload,secret){const data=b64(enc.encode(JSON.stringify(payload))),key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return data+'.'+b64(await crypto.subtle.sign('HMAC',key,enc.encode(data)));}
const headers = {'cache-control':'private, no-store','referrer-policy':'no-referrer','x-content-type-options':'nosniff','x-frame-options':'DENY','x-robots-tag':'noindex, nofollow'};
const json = (value,status=200,extra={}) => new Response(JSON.stringify(value), {status,headers:{...headers,'content-type':'application/json; charset=utf-8',...extra}});
const message = (text,status) => new Response(text,{status,headers:{...headers,'content-type':'text/plain; charset=utf-8'}});
const unavailable = () => message('验证服务暂时不可用，请稍后重试。',503);
const redirect = (url,extra={}) => new Response(null,{status:302,headers:{...headers,location:url,...extra}});
function cookie(request){return (request.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('arg_site='))?.slice(9)||'';}
const sessionCookie = token => `arg_site=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${token?'28800':'0'}`;
const managerCookie = token => `forum_manager=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${token?'28800':'0'}`;
function readManager(request){return (request.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('forum_manager='))?.slice(14)||'';}
async function isManager(request,env){const proof=await verify(readManager(request),env.SITE_KEY,'forum-manager',env.SITE_ID);return !!proof&&proof.binding===await sha(cookie(request));}
async function managerCredentials(username,password,env){if(!env.MANAGER_USERNAME_HASH_SHA256||!env.MANAGER_PASSWORD_SALT||!env.MANAGER_PASSWORD_HASH||await sha(username)!==env.MANAGER_USERNAME_HASH_SHA256)return false;const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:enc.encode(env.MANAGER_PASSWORD_SALT),iterations:100000},key,256))===env.MANAGER_PASSWORD_HASH;}
function validOrigin(value){try{const u=new URL(value);return u.protocol==='https:' && u.origin===value;}catch{return false;}}
function validAvatar(value){if(!value)return true;try{const match=/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(value);if(!match||value.length>400000)return false;const data=atob(match[2]);if(match[1]==='png')return data.startsWith('\x89PNG\r\n\x1a\n');if(match[1]==='jpeg')return data.startsWith('\xff\xd8\xff');return data.startsWith('RIFF')&&data.slice(8,12)==='WEBP';}catch{return false;}}
async function verify(token,secret,type,site){
  try{const parts=token.split('.');if(parts.length!==2)return null;const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['verify']);if(!await crypto.subtle.verify('HMAC',key,unb64(parts[1]),enc.encode(parts[0])))return null;const data=JSON.parse(new TextDecoder().decode(unb64(parts[0])));if(data.type!==type||data.site!==site||!Number.isFinite(data.exp)||data.exp<=now())return null;return data;}catch{return null;}
}
async function service(env,path,body,clientRequest){
  let response;
  try{const h={'content-type':'application/json',origin:env.SITE_ORIGIN},ip=clientRequest?.headers.get('cf-connecting-ip');if(ip&&/^[0-9a-fA-F:.]{2,45}$/.test(ip))h['cf-connecting-ip']=ip;const req=new Request(env.AUTH_ORIGIN+path,{method:'POST',redirect:'manual',signal:AbortSignal.timeout(12000),headers:h,body:JSON.stringify(body)});response=await (env.AUTH_SERVICE?env.AUTH_SERVICE.fetch(req):fetch(req));}catch(error){console.warn('ARG_SERVICE_DIAGNOSTIC',error.name,error.message);throw Error('auth unavailable');}
  if(response.status>=300&&response.status<400)throw Error('unexpected auth redirect');
  if(response.status>=500||response.status===429){console.warn('ARG_SERVICE_DIAGNOSTIC','upstream-status',response.status);throw Error('auth unavailable');}
  let data;try{data=await response.json();}catch{console.warn('ARG_SERVICE_DIAGNOSTIC','invalid-json',response.status,response.headers.get('content-type'));throw Error('auth unavailable');}return {response,data};
}
async function exchange(env,token){
  const ticket=await verify(token,env.SITE_KEY,'ticket',env.SITE_ID);
  if(!ticket||typeof ticket.dest!=='string'||!ticket.dest.startsWith('/')||ticket.dest.startsWith('//')||ticket.dest.includes('%')||ticket.dest.includes('\\'))return null;
  const dest=new URL(ticket.dest,env.SITE_ORIGIN);
  if(dest.origin!==env.SITE_ORIGIN||dest.pathname!==ticket.dest||dest.pathname.startsWith('/_arg/')||PUBLIC.has(dest.pathname))return null;
  const {response,data}=await service(env,'/api/site/redeem',{site:env.SITE_ID,token});
  if(!response.ok||!await verify(data.session||'',env.SITE_KEY,'site',env.SITE_ID))return null;
  return {session:data.session,destination:dest.href};
}
async function authorized(request,env){
  const token=cookie(request);if(!await verify(token,env.SITE_KEY,'site',env.SITE_ID))return false;
  const {response}=await service(env,'/api/site/check',{site:env.SITE_ID,token});return response.ok;
}
async function asset(request,env){let response=await env.ASSETS.fetch(request);for(let i=0;i<3&&[301,302,307,308].includes(response.status);i++){const target=new URL(response.headers.get('location')||'',request.url);if(target.origin!==env.SITE_ORIGIN)return message('Invalid asset redirect.',502);response=await env.ASSETS.fetch(new Request(target,request));}const h=new Headers(response.headers);for(const [key,value] of Object.entries(headers))h.set(key,value);return new Response(response.body,{status:response.status,statusText:response.statusText,headers:h});}
export default {async fetch(request,env){
  const url=new URL(request.url);
  if(!validOrigin(env.SITE_ORIGIN)||url.origin!==env.SITE_ORIGIN)return message('Unknown site origin.',403);
  let path;try{if(/%(?:2f|5c|25)/i.test(url.pathname))throw 0;path=decodeURIComponent(url.pathname);if(path.includes('\\')||path.split('/').some(p=>p==='.'||p==='..'))throw 0;}catch{return message('Invalid path.',400);}
  if(PUBLIC.has(path))return ['GET','HEAD'].includes(request.method)?asset(request,env):message('Method not allowed.',405);
  if(env.PROTECTED_PREFIX!=='/'||!validOrigin(env.AUTH_ORIGIN)||!/^[a-z0-9][a-z0-9-]{0,39}$/.test(env.SITE_ID||'')||typeof env.SITE_KEY!=='string'||env.SITE_KEY.length<32)return unavailable();
  if(path==='/_arg/callback'){
    if(request.method!=='GET')return message('Method not allowed.',405);
    try{const result=await exchange(env,url.searchParams.get('ticket')||'');if(!result)return message('登录票据无效、已使用或已过期，请重新登录。',403);return redirect(result.destination,{'set-cookie':sessionCookie(result.session)});}catch{return unavailable();}
  }
  if(path==='/_arg/session'){
    if(request.method!=='GET')return json({ok:false},405);
    try{const ok=await authorized(request,env),admin=ok&&await isManager(request,env);let profile=null;if(ok&&env.FORUM_PROFILES){const raw=(request.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('forum_identity='))?.slice(15)||'',identity=await verify(raw,env.SITE_KEY,'forum-identity',env.SITE_ID);if(identity&&identity.binding===await sha(cookie(request)))profile=await env.FORUM_PROFILES.prepare('SELECT uid,display_name,avatar FROM forum_profiles WHERE uid=?').bind(identity.uid).first();}return json({ok,admin,...(profile?{profile}:{})},ok?200:401);}catch{return unavailable();}
  }
  if(path==='/_arg/profiles'){
    if(request.method!=='GET')return json({error:'Method not allowed'},405);
    try{if(!await authorized(request,env))return json({error:'请先登录'},401);if(!env.FORUM_PROFILES)return json({error:'资料服务不可用'},503);const rows=await env.FORUM_PROFILES.prepare('SELECT id,uid,existing_uid,display_name,avatar,created_at FROM forum_profiles WHERE uid IS NOT NULL ORDER BY id').all();return json({profiles:rows.results});}catch{return json({error:'资料服务暂时不可用'},503);}
  }
  if(path==='/_arg/admin/accounts'){
    if(request.method!=='POST'||request.headers.get('origin')!==env.SITE_ORIGIN)return json({error:'请求来源不允许'},403);
    try{
      if(!await authorized(request,env)||!await isManager(request,env))return json({error:'请先使用原管理员账号登录管理窗口'},403);
      let d;try{const text=await request.text();if(text.length>450000)throw 0;d=JSON.parse(text);if(typeof d.username!=='string'||!d.username.trim()||d.username!==d.username.trim()||d.username.length>80||typeof d.password!=='string'||!d.password||d.password.length>256)throw 0;}catch{return json({error:'请输入有效的账号和密码'},400);}
      if(await sha(d.username)===env.MANAGER_USERNAME_HASH_SHA256)return json({error:'原管理员账号保持不变，请为浏览者设置其他账号'},400);
      let accountId,profile=d.profile;
      if(profile){if(!env.FORUM_PROFILES)return json({error:'资料服务不可用'},503);if(typeof profile.name!=='string'||!profile.name.trim()||profile.name.length>32||profile.existingUid&&!/^\d{8}$/.test(profile.existingUid)||typeof profile.avatar!=='string'||!validAvatar(profile.avatar))return json({error:'请检查昵称、已有用户和头像'},400);accountId=await accountKey(env,d.username);const other=profile.existingUid?await env.FORUM_PROFILES.prepare('SELECT account_key FROM forum_profiles WHERE uid = ?').bind(profile.existingUid).first():null;if(other&&other.account_key!==accountId)return json({error:'该用户已经绑定其他登录账号'},409);}
      const token=await sign({type:'account-management',site:env.SITE_ID,action:'upsert',nonce:crypto.randomUUID(),exp:now()+60,payloadHash:await sha(JSON.stringify({username:d.username,password:d.password}))},env.SITE_KEY);
      const {response,data}=await service(env,'/api/site/accounts',{site:env.SITE_ID,token,username:d.username,password:d.password},request);
      if(!response.ok)return json({error:data.error||'账号登记未完成'},response.status);
      if(profile){try{await env.FORUM_PROFILES.prepare('INSERT INTO forum_profiles (account_key,existing_uid,display_name,avatar,created_at) VALUES (?,?,?,?,?) ON CONFLICT(account_key) DO UPDATE SET existing_uid=excluded.existing_uid,display_name=excluded.display_name,avatar=CASE WHEN length(excluded.avatar)=0 THEN forum_profiles.avatar ELSE excluded.avatar END').bind(accountId,profile.existingUid||null,profile.name.trim(),profile.avatar,new Date().toISOString().slice(0,10)).run();const row=await env.FORUM_PROFILES.prepare('SELECT id FROM forum_profiles WHERE account_key=?').bind(accountId).first();const uid=profile.existingUid||String(90000000+row.id);if(uid.length!==8)throw Error('UID unavailable');await env.FORUM_PROFILES.prepare('UPDATE forum_profiles SET uid=? WHERE account_key=?').bind(uid,accountId).run();return json({ok:true,uid});}catch{return json({error:'登录账号已登记，但用户资料保存失败；请使用相同账号重试'},503);}}
      return json({ok:true});
    }catch{return json({error:'验证服务暂时不可用，账号未确认登记，请稍后重试'},503);}
  }
  if(path==='/_arg/login'||path==='/_arg/appeal'){
    if(request.method!=='POST'||request.headers.get('origin')!==env.SITE_ORIGIN)return json({error:'请求来源不允许'},403);
    let body;try{const text=await request.text();if(text.length>8192)throw 0;body=JSON.parse(text);if(typeof body.password!=='string'||!body.password||body.password.length>256)throw 0;if(path.endsWith('/login')&&(typeof body.username!=='string'||!body.username.trim()||body.username.length>80))throw 0;if(path.endsWith('/appeal')&&(typeof body.proof!=='string'||body.proof.length>4096))throw 0;}catch{return json({error:'请检查账号和密码'},400);}
    const payload={site:env.SITE_ID,password:body.password,...(path.endsWith('/appeal')?{proof:body.proof}:{username:body.username.trim()})};
    try{
      const {response,data}=await service(env,'/api/player/'+(path.endsWith('/appeal')?'appeal':'login')+'?site='+encodeURIComponent(env.SITE_ID),payload,request);
      if(!response.ok)return json({error:response.status===401?'账号、密码或二级密码有误':'验证失败，请检查账号或稍后再试'},response.status===401?401:403);
      if(data.stage==='appeal'&&typeof data.proof==='string')return json({stage:'appeal',proof:data.proof});
      const callback=new URL(data.redirect);if(callback.origin!==env.SITE_ORIGIN||callback.pathname!=='/_arg/callback')return unavailable();
      const result=await exchange(env,callback.searchParams.get('ticket')||'');if(!result)return json({error:'验证已过期，请重试'},401);
      const admin=path.endsWith('/login')&&await managerCredentials(payload.username,payload.password,env);
      const resultResponse=json({ok:true,admin});resultResponse.headers.append('set-cookie',sessionCookie(result.session));resultResponse.headers.append('set-cookie',managerCookie(admin?await sign({type:'forum-manager',site:env.SITE_ID,binding:await sha(result.session),exp:now()+28800},env.SITE_KEY):''));let identity='';if(env.FORUM_PROFILES&&payload.username){const profile=await env.FORUM_PROFILES.prepare('SELECT uid FROM forum_profiles WHERE account_key=?').bind(await accountKey(env,payload.username)).first();if(profile?.uid)identity=await sign({type:'forum-identity',site:env.SITE_ID,uid:profile.uid,binding:await sha(result.session),exp:now()+28800},env.SITE_KEY);}resultResponse.headers.append('set-cookie',`forum_identity=${identity}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${identity?'28800':'0'}`);return resultResponse;
    }catch{return json({error:'验证服务暂时不可用，请稍后重试'},503);}
  }
  if(path==='/_arg/logout'){
    const source=request.headers.get('origin');
    const sameOrigin=source===env.SITE_ORIGIN || ((!source||source==='null')&&request.headers.get('sec-fetch-site')==='same-origin');
    if(request.method!=='POST'||!sameOrigin)return json({error:'请求来源不允许'},403);
    const token=cookie(request);try{if(await verify(token,env.SITE_KEY,'site',env.SITE_ID)){const {response}=await service(env,'/api/site/logout',{site:env.SITE_ID,token});if(!response.ok)return json({error:'退出未完成，请重试'},503);}}catch{return unavailable();}
    const response=redirect(env.SITE_ORIGIN+'/entry.html',{'set-cookie':sessionCookie('')});response.headers.append('set-cookie',managerCookie(''));response.headers.append('set-cookie','forum_identity=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0');return response;
  }
  if(path.startsWith('/_arg/'))return message('Not found.',404);
  if(!['GET','HEAD'].includes(request.method))return message('Method not allowed.',405);
  try{if(!await authorized(request,env))return redirect(env.SITE_ORIGIN+'/entry.html'+(url.searchParams.get('ui')==='classic'?'?ui=classic':''));if((path==='/author'||path.startsWith('/author/'))&&!await isManager(request,env))return redirect(env.SITE_ORIGIN+'/login.html?next=author');}catch{return unavailable();}
  if(/^\/(?:author\/)?assets\/photos\/(?:street|umbrella|radio|meal|plant|tickets|books|bridge|skyline|avenue|police-gate)\.png$/.test(path))return redirect(env.SITE_ORIGIN+path.slice(0,-4)+'.jpg'+url.search);
  if(path==='/author')return redirect(env.SITE_ORIGIN+'/author/'+url.search);
  if(/^\/(?:index|login|register|search|members|about|rules|snapshot|thread(?:-\d+)?|user(?:-\d+)?|board(?:-[a-z]+(?:-\d+)?)?|author\/index)$/.test(path))return redirect(env.SITE_ORIGIN+path+'.html'+url.search);
  return asset(request,env);
}};
