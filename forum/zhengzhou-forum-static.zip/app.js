(() => {
 'use strict';
 const show=(form,message)=>{let box=form.querySelector('.feedback');if(!box){box=document.createElement('div');box.className='feedback';box.setAttribute('role','status');form.append(box)}box.textContent=message};
 document.querySelectorAll('[data-auth]').forEach(form=>form.addEventListener('submit',event=>{event.preventDefault();show(form,'账号或密码错误，请检查后重试。');form.querySelectorAll('[type=password]').forEach(input=>input.value='')}));
 document.querySelectorAll('[data-reply]').forEach(form=>form.addEventListener('submit',event=>{event.preventDefault();show(form,'您尚未登录，请先登录后再发表回复。')}));
 document.querySelectorAll('[data-quote]').forEach(button=>button.addEventListener('click',()=>{const input=document.querySelector('#reply-text');if(!input)return;const floor=document.getElementById('floor-'+button.dataset.quote),name=floor.querySelector('.username').textContent,body=[...floor.querySelectorAll('.post-body > p')].map(p=>p.textContent).join('\n')||'原楼层内容暂不可见。';input.setRangeText('[quote]'+name+'（'+button.dataset.quote+' 楼）：\n'+body+'\n[/quote]\n',input.selectionStart,input.selectionEnd,'end');input.focus();input.scrollIntoView({block:'center'})}));
 document.querySelectorAll('[data-local-message]').forEach(button=>button.addEventListener('click',()=>{const status=document.getElementById('page-status');if(status){status.textContent=button.dataset.localMessage;status.hidden=false;status.scrollIntoView({block:'nearest'})}}));
 const picker=document.querySelector('#face-picker'),reply=document.querySelector('#reply-text'),faceToggle=document.querySelector('[data-toggle-faces]');
 faceToggle?.addEventListener('click',()=>{picker.hidden=!picker.hidden;faceToggle.setAttribute('aria-expanded',String(!picker.hidden))});
 document.querySelectorAll('[data-insert-face]').forEach(button=>button.addEventListener('click',()=>{if(!reply)return;const label='['+button.dataset.insertFace+']',start=reply.selectionStart,end=reply.selectionEnd;reply.setRangeText(label,start,end,'end');reply.focus();picker.hidden=true;faceToggle.setAttribute('aria-expanded','false')}));
 const viewer=document.querySelector('#picture-viewer'),viewerImage=document.querySelector('#viewer-image'),viewerCaption=document.querySelector('#viewer-caption');
 document.querySelectorAll('[data-lightbox]').forEach(link=>link.addEventListener('click',event=>{if(!viewer?.showModal)return;event.preventDefault();viewerImage.src=link.getAttribute('href');viewerImage.alt=link.dataset.caption;viewerCaption.textContent=link.dataset.caption;viewer.showModal()}));
 document.querySelector('[data-close-picture]')?.addEventListener('click',()=>viewer.close());
 viewer?.addEventListener('click',event=>{if(event.target===viewer){const rect=viewer.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)viewer.close()}});
 document.querySelectorAll('[data-collapse-board]').forEach(button=>button.addEventListener('click',()=>{const table=button.closest('.panel').querySelector('table'),collapse=!table.hidden;table.hidden=collapse;button.setAttribute('aria-expanded',String(!collapse));button.textContent=collapse?'展开 ＋':'收起 －'}));
 const statusFilter=document.querySelector('[data-status-filter]'),yearFilter=document.querySelector('[data-year-filter]');
 const filterRows=()=>{let visible=0;document.querySelectorAll('[data-thread-row]').forEach(row=>{const s=!statusFilter?.value||row.dataset[statusFilter.value]==='true';const y=!yearFilter?.value||row.dataset.year===yearFilter.value;row.hidden=!(s&&y);if(!row.hidden)visible++});const empty=document.querySelector('[data-filter-empty]');if(empty)empty.hidden=visible>0};
 statusFilter?.addEventListener('change',filterRows);yearFilter?.addEventListener('change',filterRows);
 const results=document.querySelector('#search-results');
 if(results&&window.FORUM_SEARCH){
  const params=new URLSearchParams(location.search),q=(params.get('q')||'').trim(),year=params.get('year'),view=params.get('view');
  const input=document.querySelector('#full-search');if(input)input.value=q;
  let list=window.FORUM_SEARCH.filter(t=>(!q||(t.title+' '+t.author+' '+t.board).toLowerCase().includes(q.toLowerCase()))&&(!year||t.date.startsWith(year))&&(view!=='essence'||t.essence));
  list.sort((a,b)=>b.last.localeCompare(a.last));const pageSize=20,max=Math.max(1,Math.ceil(list.length/pageSize)),page=Math.min(max,Math.max(1,Number(params.get('page'))||1));
  const info=document.querySelector('#search-summary');info.textContent=`${q?'搜索 “'+q+'”':year?year+' 年旧帖':view==='essence'?'精华帖子':'全部帖子'}，共找到 ${list.length} 条记录。`;
  const frag=document.createDocumentFragment();list.slice((page-1)*pageSize,page*pageSize).forEach(t=>{const item=document.createElement('article');item.className='search-result';const h=document.createElement('h3'),a=document.createElement('a');a.href=t.url;a.textContent=t.title;h.append(a);const p=document.createElement('p');p.textContent=`${t.board}　｜　${t.author}　｜　${t.date}　｜　${t.deleted?'已删除 / 审核中':t.locked?'已锁定':'可阅读'}　｜　回复 ${t.replies}`;item.append(h,p);if(t.id===38){const cache=document.createElement('a');cache.href='snapshot.html';cache.textContent='查看已保存的网页快照 »';cache.style.color='#6486a2';item.append(cache)}frag.append(item)});results.replaceChildren(frag);if(!list.length){const empty=document.createElement('p');empty.className='empty';empty.textContent='没有找到相关帖子，试试更短的关键词。';results.append(empty)}
  const pager=document.querySelector('#search-pages');for(let n=1;n<=max;n++){const link=document.createElement(n===page?'span':'a');link.textContent=String(n);if(n===page)link.className='current';else{const next=new URLSearchParams(params);next.set('page',String(n));link.href='search.html?'+next.toString()}pager.append(link)}
 }
})();
