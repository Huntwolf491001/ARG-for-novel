@echo off
cd /d "%~dp0"
title Local website preview
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0preview-server.ps1"
if errorlevel 1 pause
