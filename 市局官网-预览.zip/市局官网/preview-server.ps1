$ErrorActionPreference = 'Stop'
$siteRoot = [System.IO.Path]::GetFullPath($PSScriptRoot).TrimEnd([char]'\') + '\'
$listener = $null
foreach ($port in 8801..8820) {
    $candidate = New-Object System.Net.HttpListener
    $candidate.Prefixes.Add("http://127.0.0.1:$port/")
    try { $candidate.Start(); $listener = $candidate; break }
    catch { $candidate.Close() }
}
if (-not $listener) { Write-Host 'Could not start server: ports 8801-8820 are unavailable.'; exit 1 }
$url = "http://127.0.0.1:$port/"
Write-Host "Website preview: $url"
Write-Host 'Keep this window open while browsing. Press Ctrl+C or close it to stop.'
try { Start-Process $url } catch { Write-Host "Open $url in a browser." }
$mime = @{
    '.html'='text/html; charset=utf-8'; '.css'='text/css; charset=utf-8';
    '.js'='application/javascript; charset=utf-8'; '.json'='application/json; charset=utf-8';
    '.svg'='image/svg+xml'; '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg';
    '.gif'='image/gif'; '.ico'='image/x-icon'; '.webp'='image/webp'; '.txt'='text/plain; charset=utf-8'
}
try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $response = $context.Response
        try {
            if ($context.Request.HttpMethod -notin @('GET','HEAD')) { $response.StatusCode = 405; continue }
            $relative = [System.Uri]::UnescapeDataString($context.Request.Url.AbsolutePath).TrimStart([char]'/').Replace('/', '\')
            $target = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($siteRoot, $relative))
            if (-not $target.StartsWith($siteRoot, [System.StringComparison]::OrdinalIgnoreCase) -and $target -ne $siteRoot.TrimEnd([char]'\')) { $response.StatusCode = 403; continue }
            if ([System.IO.Directory]::Exists($target)) { $target = [System.IO.Path]::Combine($target, 'index.html') }
            if (-not [System.IO.File]::Exists($target)) { $response.StatusCode = 404; continue }
            $ext = [System.IO.Path]::GetExtension($target).ToLowerInvariant()
            $response.ContentType = if ($mime.ContainsKey($ext)) { $mime[$ext] } else { 'application/octet-stream' }
            $bytes = [System.IO.File]::ReadAllBytes($target)
            $response.ContentLength64 = $bytes.Length
            if ($context.Request.HttpMethod -eq 'GET') { $response.OutputStream.Write($bytes, 0, $bytes.Length) }
        } catch { $response.StatusCode = 500 }
        finally { $response.Close() }
    }
} finally { $listener.Stop(); $listener.Close() }
