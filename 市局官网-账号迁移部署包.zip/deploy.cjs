const {spawnSync}=require('node:child_process');
const fs=require('node:fs'),path=require('node:path'),readline=require('node:readline');
const rl=readline.createInterface({input:process.stdin,output:process.stdout});
const ask=q=>new Promise(r=>rl.question(q,r));
const run=(file,args,options={})=>{const r=spawnSync(file,args,{cwd:__dirname,stdio:options.capture?'pipe':'inherit',encoding:'utf8',shell:!!options.shell,env:process.env});if(r.status!==0)throw Error('命令失败：'+file+' '+args.join(' '));return r.stdout||''};
async function main(){
 console.log('市局网站迁移向导：仅迁移 Pages，继续使用现有验证服务。');
 console.log('请先确保旧项目已删除；Cloudflare 不保证原 pages.dev 域名可在另一账号复用。');
 const id=(await ask('输入新 Cloudflare 账号的 Account ID（32位十六进制）：')).trim();
 if(!/^[a-f0-9]{32}$/i.test(id))throw Error('账号 ID 格式无效');
 process.env.CLOUDFLARE_ACCOUNT_ID=id;
 if(!fs.existsSync(path.join(__dirname,'node_modules','wrangler','bin','wrangler.js'))){console.log('正在安装部署工具，请保持网络连接……');run('npm.cmd',['install','--no-audit','--no-fund'],{shell:true});}
 const bin=path.join(__dirname,'node_modules','wrangler','bin','wrangler.js');
 console.log('请在打开的 Cloudflare 登录页面中选择新账号。');
 run(process.execPath,[bin,'login']);
 run(process.execPath,[bin,'whoami']);
 const go=(await ask('确认上方登录身份和账号 ID 均属于新账号？输入 YES 继续：')).trim();if(go!=='YES')throw Error('已停止，请重新运行并确认账号');
 let list=JSON.parse(run(process.execPath,[bin,'pages','project','list','--json'],{capture:true}));
 let project=list.find(x=>x['Project Name']==='zhengzhou-police');
 if(!project){run(process.execPath,[bin,'pages','project','create','zhengzhou-police','--production-branch','main']);list=JSON.parse(run(process.execPath,[bin,'pages','project','list','--json'],{capture:true}));project=list.find(x=>x['Project Name']==='zhengzhou-police');}
 else if((await ask('新账号中已有同名项目；确认这是本次迁移创建的项目并允许更新？输入 YES 继续：')).trim()!=='YES')throw Error('为避免覆盖已有项目，已停止');
 if(!project || !String(project['Project Domains']||'').split(/[\s,]+/).includes('zhengzhou-police.pages.dev'))throw Error('未取得原域名，已停止上传；请检查 Pages 项目列表与 Cloudflare 控制台。');
 console.log('已确认项目域名。现在请在新账号的 Cloudflare Pages 控制台，为 zhengzhou-police 的生产环境添加 Secret：SITE_KEY。');
 console.log('值必须与原验证服务 city-bureau 站点的签名密钥完全相同，可在验证服务控制面板中查看。请勿发送给他人或粘贴到此窗口。');
 console.log('确认旧验证服务仍可使用，且其登记的网站地址为 https://zhengzhou-police.pages.dev。');
 if((await ask('在控制台完成密钥配置后输入 YES 继续：')).trim()!=='YES')throw Error('已停止，完成密钥配置后可重新运行');
 run(process.execPath,[bin,'pages','deploy','public','--project-name','zhengzhou-police','--branch','main','--commit-dirty=true']);
 const response=await fetch('https://zhengzhou-police.pages.dev/archive/',{redirect:'manual',signal:AbortSignal.timeout(15000)});
 if(response.status!==302 || !String(response.headers.get('location')||'').includes('/login.html'))throw Error('上传完成，但未登录访问保护检查未通过（HTTP '+response.status+'）；请立即检查线上配置');
 console.log('部署完成；未登录访问受保护目录已跳转登录。请使用原账号实际检查两步登录、找回和退出。');
}
main().catch(e=>{console.error('迁移未完成：'+e.message);process.exitCode=1}).finally(()=>rl.close());
