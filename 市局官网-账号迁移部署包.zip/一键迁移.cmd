@echo off
cd /d "%~dp0"
where node >nul 2>&1 || (echo Node.js is required. Install Node.js LTS first. & pause & exit /b 1)
where npm >nul 2>&1 || (echo npm is required. & pause & exit /b 1)
node deploy.cjs
echo.
pause
